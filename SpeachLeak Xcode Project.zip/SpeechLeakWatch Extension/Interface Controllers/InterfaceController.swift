//
//  InterfaceController.swift
//  SpeechLeakWatch Extension
//
//  Created by Wayne Hartman on 2/17/20.
//  Copyright © 2020 Wayne Hartman. All rights reserved.
//

import WatchKit

class InterfaceController: WKInterfaceController {

}
