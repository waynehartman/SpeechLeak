//
//  ViewController.swift
//  SpeechLeak
//
//  Created by Wayne Hartman on 2/17/20.
//  Copyright © 2020 Wayne Hartman. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

